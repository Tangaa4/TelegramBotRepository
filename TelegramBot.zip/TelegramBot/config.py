exchanges = {
    'доллар': 'USD',
    'рубль': 'RUB',
    'евро': 'EUR'
}

TOKEN = "5430311570:AAH-EThT4xhW2EYRMkV0S1izXe2Cw6p-9r4"